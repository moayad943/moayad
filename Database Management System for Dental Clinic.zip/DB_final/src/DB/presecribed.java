package DB;

public class presecribed {

	private int pnum;
	private int DCode ;
	private String DrEmail;
	public presecribed(int pnum, int dCode, String drEmail) {
		super();
		this.pnum = pnum;
		DCode = dCode;
		DrEmail = drEmail;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getDCode() {
		return DCode;
	}
	public void setDCode(int dCode) {
		DCode = dCode;
	}
	public String getDrEmail() {
		return DrEmail;
	}
	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}

	
	
}
