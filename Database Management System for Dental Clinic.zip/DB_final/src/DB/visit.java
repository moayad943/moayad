package DB;
public class visit {

	private int pnum;
	private int DiaCode;
	private String DrEmail;
	public visit(int pnum, int diaCode, String drEmail) {
		super();
		this.pnum = pnum;
		DiaCode = diaCode;
		DrEmail = drEmail;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getDiaCode() {
		return DiaCode;
	}
	public void setDiaCode(int diaCode) {
		DiaCode = diaCode;
	}
	public String getDrEmail() {
		return DrEmail;
	}
	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}

	
	
}
