package DB;

public class doctor {
	private String DrEmail;
	private String DrName;
	private String DrPhone;
	public doctor(String drEmail, String drName, String drPhone) {
		super();
		DrEmail = drEmail;
		DrName = drName;
		DrPhone = drPhone;
	}
	public String getDrEmail() {
		return DrEmail;
	}
	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}
	public String getDrName() {
		return DrName;
	}
	public void setDrName(String drName) {
		DrName = drName;
	}
	public String getDrPhone() {
		return DrPhone;
	}
	public void setDrPhone(String drPhone) {
		DrPhone = drPhone;
	}
	
	


}
