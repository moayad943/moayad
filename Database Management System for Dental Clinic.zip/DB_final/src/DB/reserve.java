package DB;

public class reserve {

	private int pnum;
	private int ANum;
	private String DrEmail;
	public reserve(int pnum, int aNum, String drEmail) {
		super();
		this.pnum = pnum;
		ANum = aNum;
		DrEmail = drEmail;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getANum() {
		return ANum;
	}
	public void setANum(int aNum) {
		ANum = aNum;
	}
	public String getDrEmail() {
		return DrEmail;
	}
	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}

}
