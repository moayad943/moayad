
package DB;

public class drug {

	private int DCode;
	private String DName;
	private String DDStart;
	private String DDEnd;
	private String DDesc;
	
	
	public drug(int dCode, String dName, String dDStart, String dDEnd, String dDesc) {
		super();
		DCode = dCode;
		DName = dName;
		DDStart = dDStart;
		DDEnd = dDEnd;
		DDesc = dDesc;
	}


	public int getDCode() {
		return DCode;
	}


	public void setDCode(int dCode) {
		DCode = dCode;
	}


	public String getDName() {
		return DName;
	}


	public void setDName(String dName) {
		DName = dName;
	}


	public String getDDStart() {
		return DDStart;
	}


	public void setDDStart(String dDStart) {
		DDStart = dDStart;
	}


	public String getDDEnd() {
		return DDEnd;
	}


	public void setDDEnd(String dDEnd) {
		DDEnd = dDEnd;
	}


	public String getDDesc() {
		return DDesc;
	}


	public void setDDesc(String dDesc) {
		DDesc = dDesc;
	}



}