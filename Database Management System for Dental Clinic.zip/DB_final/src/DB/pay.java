package DB;

public class pay {

	private int pnum;
	private int CCode;
	private String PayMethod;
	public pay(int pnum, int cCode, String payMethod) {
		super();
		this.pnum = pnum;
		CCode = cCode;
		PayMethod = payMethod;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getCCode() {
		return CCode;
	}
	public void setCCode(int cCode) {
		CCode = cCode;
	}
	public String getPayMethod() {
		return PayMethod;
	}
	public void setPayMethod(String payMethod) {
		PayMethod = payMethod;
	}
	

}
