package DB;

public class treatment {

	private int TCode;
	private int TID ;
	private String TName;
	private String TArea;
	private String TDesc ;
	
	private String DrEmail;
	private int DiaCode;
	
	public treatment(int tCode, int tID, String tName, String tArea, String tDesc, String drEmail, int diaCode) {
		super();
		TCode = tCode;
		TID = tID;
		TName = tName;
		TArea = tArea;
		TDesc = tDesc;
		DrEmail = drEmail;
		DiaCode = diaCode;
	}
	public int getTCode() {
		return TCode;
	}
	public void setTCode(int tCode) {
		TCode = tCode;
	}
	public int getTID() {
		return TID;
	}
	public void setTID(int tID) {
		TID = tID;
	}
	public String getTName() {
		return TName;
	}
	public void setTName(String tName) {
		TName = tName;
	}
	public String getTArea() {
		return TArea;
	}
	public void setTArea(String tArea) {
		TArea = tArea;
	}
	public String getTDesc() {
		return TDesc;
	}
	public void setTDesc(String tDesc) {
		TDesc = tDesc;
	}
	public String getDrEmail() {
		return DrEmail;
	}
	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}
	public int getDiaCode() {
		return DiaCode;
	}
	public void setDiaCode(int diaCode) {
		DiaCode = diaCode;
	}

	

}
