package DB;

public class cost {

	private int CCode;
	private String CDate;
	private double CTotal;
	private double CValue;
	private double CDept;

	private String DrEmail;
	private int TCode;
	private String payMethod;

	public cost(int cCode, String cDate, double cTotal, double cValue, double cDept, String drEmail, int tCode,
			String payMethod) {
		super();
		CCode = cCode;
		CDate = cDate;
		CTotal = cTotal;
		CValue = cValue;
		CDept = cDept;
		TCode = tCode;
		DrEmail = drEmail;
		this.payMethod = payMethod;
	}

	public int getCCode() {
		return CCode;
	}

	public void setCCode(int cCode) {
		CCode = cCode;
	}

	public String getCDate() {
		return CDate;
	}

	public void setCDate(String cDate) {
		CDate = cDate;
	}

	public double getCTotal() {
		return CTotal;
	}

	public void setCTotal(double cTotal) {
		CTotal = cTotal;
	}

	public double getCValue() {
		return CValue;
	}

	public void setCValue(double cValue) {
		CValue = cValue;
	}

	public double getCDept() {
		return CDept;
	}

	public void setCDept(double cDept) {
		CDept = cDept;
	}

	public int getTCode() {
		return TCode;
	}

	public void setTCode(int tCode) {
		TCode = tCode;
	}

	public String getDrEmail() {
		return DrEmail;
	}

	public void setDrEmail(String drEmail) {
		DrEmail = drEmail;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}
	
	
	

}
