package DB;


public class diagnosis {

	private int DiaCode;
	private String DiaName ;
	private String TreatNeed;
	private String DiaDesc;
	
	
	public diagnosis(int diaCode, String diaName, String treatNeed, String diaDesc) {
		super();
		DiaCode = diaCode;
		DiaName = diaName;
		TreatNeed = treatNeed;
		DiaDesc = diaDesc;
	}
	
	
	public int getDiaCode() {
		return DiaCode;
	}
	public void setDiaCode(int diaCode) {
		DiaCode = diaCode;
	}
	public String getDiaName() {
		return DiaName;
	}
	public void setDiaName(String diaName) {
		DiaName = diaName;
	}
	public String getTreatNeed() {
		return TreatNeed;
	}
	public void setTreatNeed(String treatNeed) {
		TreatNeed = treatNeed;
	}
	public String getDiaDesc() {
		return DiaDesc;
	}
	public void setDiaDesc(String diaDesc) {
		DiaDesc = diaDesc;
	}
	
	
		
	
	
	
}

