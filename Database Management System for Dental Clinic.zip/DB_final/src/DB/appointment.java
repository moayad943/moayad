package DB;

public class appointment {

	
	private int ANum;
	private int APatientNum ;
	private String ADate;
	private String AHour;
	private String ADesc;
	
	
	
	public appointment(int aNum, int aPatientNum, String aDate, String aHour, String aDesc) {
		super();
		ANum = aNum;
		APatientNum = aPatientNum;
		ADate = aDate;
		AHour = aHour;
		ADesc = aDesc;
	}



	public int getANum() {
		return ANum;
	}



	public void setANum(int aNum) {
		ANum = aNum;
	}



	public int getAPatientNum() {
		return APatientNum;
	}



	public void setAPatientNum(int aPatientNum) {
		APatientNum = aPatientNum;
	}



	public String getADate() {
		return ADate;
	}



	public void setADate(String aDate) {
		ADate = aDate;
	}



	public String getAHour() {
		return AHour;
	}



	public void setAHour(String aHour) {
		AHour = aHour;
	}



	public String getADesc() {
		return ADesc;
	}



	public void setADesc(String aDesc) {
		ADesc = aDesc;
	}
	
	
}