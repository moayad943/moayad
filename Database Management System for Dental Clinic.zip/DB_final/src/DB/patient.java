package DB;

public class patient {

	private int pnum;
	private String pname;
	private int p_id;
	private String address;
	private String dateOfBirth;
	private String sex;
	private String phoneNum;
	private String Pstatus;
	
	
	public patient(int pnum, String pname, int p_id, String address, String dateOfBirth, String sex, String phoneNum,
			String pstatus) {
		super();
		this.pnum = pnum;
		this.pname = pname;
		this.p_id = p_id;
		this.address = address;
		this.dateOfBirth = dateOfBirth;
		this.sex = sex;
		this.phoneNum = phoneNum;
		Pstatus = pstatus;
	}

	public int getPnum() {
		return pnum;
	}

	public void setPnum(int pnum) {
		this.pnum = pnum;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getPstatus() {
		return Pstatus;
	}

	public void setPstatus(String pstatus) {
		Pstatus = pstatus;
	}

}
