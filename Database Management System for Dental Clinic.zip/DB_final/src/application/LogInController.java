package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class LogInController {
	@FXML
	private TextField email;
	@FXML
	private PasswordField pass;
	@FXML
	private Label msg;
	
	
	private String DrEmail = "";
	private String DrPass = "";

	public void connectToDB() {
		Connection conn = null;
		try {
			Class.forName(DBconnection.Class);
			conn = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername,
					DBconnection.DbPassword);
			if (conn != null) {
				
			} else {
				System.out.println("Not connected");
			}
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select d.doctor_email from doctor d;");

			while (rs.next())
				if (rs.getString(1).toLowerCase().equals(email.getText().toLowerCase())) {
					DrEmail = rs.getString(1);
					DrPass = pass.getText();
					
					Main.setCurrentEmail(DrEmail);
					Main.setCurrentPass(DrPass);

					break;
				}
			conn.close();
		} catch (Exception e) {
			System.err.println("User not found");
		}

	}

	public void LogIN(ActionEvent event) throws IOException {

		connectToDB();

		if (DrEmail.equals("ayadental@gmail.com") && DrPass.equals("1999")) {

			((Node) (event.getSource())).getScene().getWindow().hide();

			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));

			Scene scene = new Scene(root, 600, 601);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(601);
			primaryStage.setMinWidth(600);
			primaryStage.setTitle("Clinic Care�");
			primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
			primaryStage.show();
		}else if (!DrEmail.equals("ayadental@gmail.com")) {
			msg.setText("Email is inncorrect !");
		}else if (!DrPass.equals("1999")) {
			msg.setText("Password is inncorrect !");
		}
	}

}
