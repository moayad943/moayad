package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DB.appointment;
import DB.cost;
import DB.diagnosis;
import DB.drug;
import DB.patient;
import DB.treatment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

public class GUIController extends Update {

	@FXML
	private Button LogInB;
	@FXML
	private TextField patNumT;
	@FXML
	private TextField patNameT;
	@FXML
	private TextField patIDT;
	@FXML
	private TextField patAddT;
	@FXML
	private TextField patDOBT;
	@FXML
	private TextField patGenT;
	@FXML
	private TextField patPhonT;
	@FXML
	private TextField patStaT;
	@FXML
	private TextField searchA;
	@FXML
	private TextField searchP;
	@FXML
	private TextField showMon;

	@FXML
	private TableView<patient> mainTable = new TableView<patient>();
	@FXML
	private TableView<appointment> appTable = new TableView<appointment>();
	@FXML
	private TableView<diagnosis> diagTable = new TableView<diagnosis>();
	@FXML
	private TableView<treatment> treatTable = new TableView<treatment>();
	@FXML
	private TableView<appointment> appoPaTable = new TableView<appointment>();
	@FXML
	private TableView<cost> costTable = new TableView<cost>();
	@FXML
	private TableView<drug> drugTable = new TableView<drug>();
	@FXML
	private TableView<patient> onePaTable = new TableView<patient>();
	@FXML
	private TableView<appointment> MonAppoPaTable = new TableView<appointment>();
	@FXML
	private TableView<cost> MonCostTable = new TableView<cost>();

	/*
	 * Patient Table
	 * 
	 */
	private ArrayList<patient> pdata;
	private ObservableList<patient> PdataList;

	private TableColumn<patient, Integer> pnum;
	private TableColumn<patient, String> pname;
	private TableColumn<patient, Integer> p_id;
	private TableColumn<patient, String> address;
	private TableColumn<patient, String> dateOfBirth;
	private TableColumn<patient, String> sex;
	private TableColumn<patient, String> phoneNum;
	private TableColumn<patient, String> Pstatus;

	/*
	 * Appointment Table
	 * 
	 */
	private ArrayList<appointment> appodata;
	private ObservableList<appointment> appodataList;

	private TableColumn<appointment, Integer> ANum;
	private TableColumn<appointment, Integer> APatientNum;
	private TableColumn<appointment, String> ADate;
	private TableColumn<appointment, String> AHour;
	private TableColumn<appointment, String> ADesc;

	/*
	 * Diagnosis Table
	 * 
	 */
	private ArrayList<diagnosis> diagdata;
	private ObservableList<diagnosis> diagdataList;

	private TableColumn<diagnosis, Integer> DiaCode;
	private TableColumn<diagnosis, String> DiaName;
	private TableColumn<diagnosis, String> TreatNeed;
	private TableColumn<diagnosis, String> DiaDesc;

	/*
	 * Treatment Table
	 * 
	 */
	private ArrayList<treatment> treatdata;
	private ObservableList<treatment> treatdataList;

	private TableColumn<treatment, Integer> TCode;
	private TableColumn<treatment, Integer> TID;
	private TableColumn<treatment, String> TName;
	private TableColumn<treatment, String> TArea;
	private TableColumn<treatment, String> TDesc;

	/*
	 * Appointment Patient Table
	 * 
	 */
	private ArrayList<appointment> appoPadata;
	private ObservableList<appointment> appoPadataList;

	/*
	 * Cost Table
	 * 
	 */
	private ArrayList<cost> costdata;
	private ObservableList<cost> costdataList;

	private TableColumn<cost, Integer> CCode;
	private TableColumn<cost, String> CDate;
	private TableColumn<cost, Double> CTotal;
	private TableColumn<cost, Double> CValue;
	private TableColumn<cost, Double> CDept;
	private TableColumn<cost, String> payMethod;

	/*
	 * Drug Table
	 * 
	 */
	private ArrayList<drug> drugdata;
	private ObservableList<drug> drugdataList;

	private TableColumn<drug, Integer> DCode;
	private TableColumn<drug, String> DName;
	private TableColumn<drug, String> DDStart;
	private TableColumn<drug, String> DDEnd;
	private TableColumn<drug, String> DDesc;

	private ArrayList<patient> onePadata;
	private ObservableList<patient> onePadataList;
	private Connection con;
	private static int flag;
	private static int mon = 0;
	private Statement stmt;
	private ResultSet rs;
	private static int key = 0;
	private static int maxpatient = 0;
	private static int maxappo = 0;
	private static int maxdaig = 0;
	private static int maxtreat = 0;
	private static int maxdaigTrear = 0;
	private static int maxPatappo = 0;
	private static int maxCost = 0;
	private static int maxTreatCost = 0;
	private static int maxDrug = 0;

	public void initialize() throws ClassNotFoundException, SQLException {

		/*
		 * System.out.println(flag);
		 */
		if (flag == 1) {
			/*
			 * Patient Table
			 * 
			 */

			try {
				mainTable.getColumns().clear();
			} catch (Exception e) {

			}

			pnum = new TableColumn("pnum");
			pnum.setMinWidth(52);
			pname = new TableColumn("pname");
			pname.setMinWidth(106);
			p_id = new TableColumn("p_id");
			p_id.setMinWidth(81);
			address = new TableColumn("address");
			address.setMinWidth(99);
			dateOfBirth = new TableColumn("dateOfBirth");
			dateOfBirth.setMinWidth(85);
			sex = new TableColumn("sex");
			sex.setMinWidth(40);
			phoneNum = new TableColumn("phoneNum");
			phoneNum.setMinWidth(116);
			Pstatus = new TableColumn("Pstatus");
			Pstatus.setMinWidth(98);

			pnum.setCellValueFactory(new PropertyValueFactory<patient, Integer>("pnum"));
			pname.setCellValueFactory(new PropertyValueFactory<patient, String>("pname"));
			p_id.setCellValueFactory(new PropertyValueFactory<patient, Integer>("p_id"));
			address.setCellValueFactory(new PropertyValueFactory<patient, String>("address"));
			dateOfBirth.setCellValueFactory(new PropertyValueFactory<patient, String>("dateOfBirth"));
			sex.setCellValueFactory(new PropertyValueFactory<patient, String>("sex"));
			phoneNum.setCellValueFactory(new PropertyValueFactory<patient, String>("phoneNum"));
			Pstatus.setCellValueFactory(new PropertyValueFactory<patient, String>("Pstatus"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from patient;");
			pdata = new ArrayList<patient>();
			while (rs.next()) {
				pdata.add(new patient(Integer.parseInt(rs.getString(1)), rs.getString(2),
						Integer.parseInt(rs.getString(3)), rs.getString(4), rs.getString(5), rs.getString(6),
						rs.getString(7), rs.getString(8)));
			}

			PdataList = FXCollections.observableArrayList(pdata);
			mainTable.setItems(PdataList);
			mainTable.getColumns().addAll(pnum, pname, p_id, address, dateOfBirth, sex, phoneNum, Pstatus);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(p.pNum) FROM patient p;");
			if (rs.next()) {
				maxpatient = Integer.parseInt(rs.getString(1));
			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * Update Patient
			 */
			mainTable.setEditable(true);

			pname.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			pname.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPname(t.getNewValue());
				updateName(t.getRowValue().getPnum(), t.getNewValue());
			});

			p_id.setCellFactory(TextFieldTableCell.<patient, Integer>forTableColumn(new IntegerStringConverter()));
			p_id.setOnEditCommit((CellEditEvent<patient, Integer> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setP_id(t.getNewValue());
				updatepatientID(t.getRowValue().getPnum(), t.getNewValue());
			});

			address.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			address.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setAddress(t.getNewValue());
				updateAdderss(t.getRowValue().getPnum(), t.getNewValue());
			});

			dateOfBirth.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			dateOfBirth.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setDateOfBirth(t.getNewValue());
				updatepatientDOB(t.getRowValue().getPnum(), t.getNewValue());
			});

			sex.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			sex.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setSex(t.getNewValue());
				updatepatientSex(t.getRowValue().getPnum(), t.getNewValue());
			});

			phoneNum.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			phoneNum.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPhoneNum(t.getNewValue());
				updatePhoneNum(t.getRowValue().getPnum(), t.getNewValue());
			});

			Pstatus.setCellFactory(TextFieldTableCell.<patient>forTableColumn());
			Pstatus.setOnEditCommit((CellEditEvent<patient, String> t) -> {
				((patient) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPstatus(t.getNewValue());
				updatePstatus(t.getRowValue().getPnum(), t.getNewValue());
			});

		}

		if (flag == 2) {

			/*
			 * Appointment Table
			 * 
			 */

			try {
				appTable.getColumns().clear();
			} catch (Exception e) {

			}

			ANum = new TableColumn("ANum");
			ANum.setMinWidth(90);

			APatientNum = new TableColumn("APatientNum");
			APatientNum.setMinWidth(110);

			ADate = new TableColumn("ADate");
			ADate.setMinWidth(140);

			AHour = new TableColumn("AHour");
			AHour.setMinWidth(100);

			ADesc = new TableColumn("ADesc");
			ADesc.setMinWidth(170);

			ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
			APatientNum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("APatientNum"));
			ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
			AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
			ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from appointment;");

			appodata = new ArrayList<appointment>();

			while (rs.next()) {
				appodata.add(new appointment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
						rs.getString(3), rs.getString(4), rs.getString(5)));
			}

			appodataList = FXCollections.observableArrayList(appodata);
			appTable.setItems(appodataList);
			appTable.getColumns().addAll(ANum, APatientNum, ADate, AHour, ADesc);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(a.appointment_number) FROM appointment a;");
			if (rs.next()) {
				maxappo = Integer.parseInt(rs.getString(1));
			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * Update Appointment
			 * 
			 */
			appTable.setEditable(true);

			APatientNum.setCellFactory(
					TextFieldTableCell.<appointment, Integer>forTableColumn(new IntegerStringConverter()));
			APatientNum.setOnEditCommit((CellEditEvent<appointment, Integer> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setAPatientNum(t.getNewValue());
				updateAPat(t.getRowValue().getANum(), t.getNewValue());
			});

			ADate.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			ADate.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setADate(t.getNewValue());
				updateADate(t.getRowValue().getANum(), t.getNewValue());
			});

			AHour.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			AHour.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setAHour(t.getNewValue());
				updateAHour(t.getRowValue().getANum(), t.getNewValue());
			});

			ADesc.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			ADesc.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setADesc(t.getNewValue());
				updateADesc(t.getRowValue().getANum(), t.getNewValue());
			});

		}

		if (flag == 3) {

			/*
			 * Patient TextField
			 * 
			 * 
			 */

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery("select  * from patient p where p.pNum=" + key + " ;");
			pdata = new ArrayList<patient>();
			while (rs.next()) {
				pdata.add(new patient(Integer.parseInt(rs.getString(1)), rs.getString(2),
						Integer.parseInt(rs.getString(3)), rs.getString(4), rs.getString(5), rs.getString(6),
						rs.getString(7), rs.getString(8)));
			}
			con.close();
			stmt.close();
			rs.close();
			patNumT.setText(pdata.get(0).getPnum() + "");
			patNameT.setText(pdata.get(0).getPname() + "");
			patIDT.setText(pdata.get(0).getP_id() + "");
			patAddT.setText(pdata.get(0).getAddress() + "");
			patDOBT.setText(pdata.get(0).getDateOfBirth() + "");
			patGenT.setText(pdata.get(0).getSex() + "");
			patPhonT.setText(pdata.get(0).getPhoneNum() + "");
			patStaT.setText(pdata.get(0).getPstatus() + "");

			/*
			 * Diagnosis Table
			 * 
			 */
			try {
				diagTable.getColumns().clear();
			} catch (Exception e) {

			}

			DiaCode = new TableColumn("DiaCode");
			DiaCode.setMinWidth(80);

			DiaName = new TableColumn("DiaName");
			DiaName.setMinWidth(120);

			TreatNeed = new TableColumn("TreatNeed");
			TreatNeed.setMinWidth(95);

			DiaDesc = new TableColumn("DiaDesc");
			DiaDesc.setMinWidth(105);

			DiaCode.setCellValueFactory(new PropertyValueFactory<diagnosis, Integer>("DiaCode"));
			DiaName.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("DiaName"));
			TreatNeed.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("TreatNeed"));
			DiaDesc.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("DiaDesc"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select d.diagnosis_code,d.problem_name,d.tratment_need,d.diagnosis_description from visit v , diagnosis d,patient p where p.pNum ="
							+ key + " and v.patientNum=" + key + " and d.diagnosis_code = v.diagnosis_code;");

			diagdata = new ArrayList<diagnosis>();

			while (rs.next()) {
				diagdata.add(new diagnosis(Integer.parseInt(rs.getString(1)), rs.getString(2), rs.getString(3),
						rs.getString(4)));
			}

			diagdataList = FXCollections.observableArrayList(diagdata);
			diagTable.setItems(diagdataList);
			diagTable.getColumns().addAll(DiaCode, DiaName, TreatNeed, DiaDesc);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(d.diagnosis_code) FROM diagnosis d;");
			if (rs.next()) {
				maxdaig = Integer.parseInt(rs.getString(1));
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(d.diagnosis_code) FROM visit v , diagnosis d,patient p where p.pNum ="
					+ key + " and v.patientNum=" + key + " and d.diagnosis_code = v.diagnosis_code;");
			if (rs.next()) {

				if (rs.getString(1) == null) {
					insertNULLDiagData();
				} else
					maxdaigTrear = Integer.parseInt(rs.getString(1));

			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * Update Diagnosis Table
			 * 
			 */
			diagTable.setEditable(true);

			DiaName.setCellFactory(TextFieldTableCell.<diagnosis>forTableColumn());
			DiaName.setOnEditCommit((CellEditEvent<diagnosis, String> t) -> {
				((diagnosis) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setDiaName(t.getNewValue());
				updateDiaName(t.getRowValue().getDiaCode(), t.getNewValue());
			});

			TreatNeed.setCellFactory(TextFieldTableCell.<diagnosis>forTableColumn());
			TreatNeed.setOnEditCommit((CellEditEvent<diagnosis, String> t) -> {
				((diagnosis) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setTreatNeed(t.getNewValue());
				updatetreatneed(t.getRowValue().getDiaCode(), t.getNewValue());
			});

			DiaDesc.setCellFactory(TextFieldTableCell.<diagnosis>forTableColumn());
			DiaDesc.setOnEditCommit((CellEditEvent<diagnosis, String> t) -> {
				((diagnosis) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setDiaDesc(t.getNewValue());
				updateDdesc(t.getRowValue().getDiaCode(), t.getNewValue());
			});

			/*
			 * Treatment Table
			 * 
			 */

			try {
				treatTable.getColumns().clear();
			} catch (Exception e) {

			}

			TCode = new TableColumn("TCode");
			TCode.setMinWidth(85);

			TID = new TableColumn("TID");
			TID.setMinWidth(75);

			TName = new TableColumn("TName");
			TName.setMinWidth(75);

			TArea = new TableColumn("TArea");
			TArea.setMinWidth(71);

			TDesc = new TableColumn("TDesc");
			TDesc.setMinWidth(94);

			TCode.setCellValueFactory(new PropertyValueFactory<treatment, Integer>("TCode"));
			TID.setCellValueFactory(new PropertyValueFactory<treatment, Integer>("TID"));
			TName.setCellValueFactory(new PropertyValueFactory<treatment, String>("TName"));
			TArea.setCellValueFactory(new PropertyValueFactory<treatment, String>("TArea"));
			TDesc.setCellValueFactory(new PropertyValueFactory<treatment, String>("TDesc"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select t.traetment_code,t.treatment_id,t.traetment_name,t.traetment_area,t.treatment_description,t.doctor_email,t.diagnosis_code from patient p,visit v, diagnosis d , treatment t where p.pNum="
							+ key + " and v.patientNum =" + key
							+ " and v.diagnosis_code  = d.diagnosis_code and d.diagnosis_code = t.diagnosis_code;");

			treatdata = new ArrayList<treatment>();

			while (rs.next()) {
				treatdata.add(new treatment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
						rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6),
						Integer.parseInt(rs.getString(7))));
			}

			treatdataList = FXCollections.observableArrayList(treatdata);
			treatTable.setItems(treatdataList);

			treatTable.getColumns().addAll(TCode, TID, TName, TArea, TDesc);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(t.traetment_code) FROM treatment t;");
			if (rs.next()) {
				maxtreat = Integer.parseInt(rs.getString(1));
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"SELECT MAX(t.traetment_code) FROM visit v , diagnosis d,patient p,treatment t where p.pNum =" + key
							+ " and v.patientNum=" + key
							+ " and d.diagnosis_code = v.diagnosis_code and t.diagnosis_code =d.diagnosis_code  ;");
			if (rs.next()) {

				if (rs.getString(1) == null) {
					insertNULLTreatData();
				} else
					maxTreatCost = Integer.parseInt(rs.getString(1));

			}
			con.close();
			stmt.close();
			rs.close();

			/*
			 * Update Treatment Table
			 * 
			 */

			treatTable.setEditable(true);

			TID.setCellFactory(TextFieldTableCell.<treatment, Integer>forTableColumn(new IntegerStringConverter()));
			TID.setOnEditCommit((CellEditEvent<treatment, Integer> t) -> {
				((treatment) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTID(t.getNewValue());
				updateTID(t.getRowValue().getTCode(), t.getNewValue());
			});

			TName.setCellFactory(TextFieldTableCell.<treatment>forTableColumn());
			TName.setOnEditCommit((CellEditEvent<treatment, String> t) -> {
				((treatment) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTName(t.getNewValue());
				updateTName(t.getRowValue().getTCode(), t.getNewValue());
			});

			TArea.setCellFactory(TextFieldTableCell.<treatment>forTableColumn());
			TArea.setOnEditCommit((CellEditEvent<treatment, String> t) -> {
				((treatment) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTArea(t.getNewValue());
				updateTArea(t.getRowValue().getTCode(), t.getNewValue());
			});

			TDesc.setCellFactory(TextFieldTableCell.<treatment>forTableColumn());
			TDesc.setOnEditCommit((CellEditEvent<treatment, String> t) -> {
				((treatment) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTDesc(t.getNewValue());
				updateTDesc(t.getRowValue().getTCode(), t.getNewValue());
			});

			/*
			 * appointment table of one patient
			 */

			try {
				appoPaTable.getColumns().clear();
			} catch (Exception e) {

			}

			ANum = new TableColumn("ANum");
			ANum.setMinWidth(81);

			ADate = new TableColumn("ADate");
			ADate.setMinWidth(121);

			AHour = new TableColumn("AHour");
			AHour.setMinWidth(95);

			ADesc = new TableColumn("ADesc");
			ADesc.setMinWidth(103);

			ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
			ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
			AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
			ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select a.appointment_number, a.appointment_patient_number,a.appointment_date,a.appointment_hour,a.appointment_description  from patient p , appointment a , reserve r  where p.pNum = "
							+ key + " and r.patientNum = " + key + " and a.appointment_number = r.appointment_number;");

			appodata = new ArrayList<appointment>();

			while (rs.next()) {
				appodata.add(new appointment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
						rs.getString(3), rs.getString(4), rs.getString(5)));
			}

			appodataList = FXCollections.observableArrayList(appodata);
			appoPaTable.setItems(appodataList);
			appoPaTable.getColumns().addAll(ANum, ADate, AHour, ADesc);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(a.appointment_number) FROM appointment a;");

			if (rs.next()) {

				maxPatappo = Integer.parseInt(rs.getString(1));
			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * update appointment table of one patient
			 */

			appoPaTable.setEditable(true);

			ADate.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			ADate.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setADate(t.getNewValue());
				updateADate(t.getRowValue().getANum(), t.getNewValue());
			});

			AHour.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			AHour.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setAHour(t.getNewValue());
				updateAHour(t.getRowValue().getANum(), t.getNewValue());
			});

			ADesc.setCellFactory(TextFieldTableCell.<appointment>forTableColumn());
			ADesc.setOnEditCommit((CellEditEvent<appointment, String> t) -> {
				((appointment) t.getTableView().getItems().get(t.getTablePosition().getRow()))
						.setADesc(t.getNewValue());
				updateADesc(t.getRowValue().getANum(), t.getNewValue());
			});

			/*
			 * 
			 * cost Table
			 * 
			 * 
			 */

			try {
				costTable.getColumns().clear();
			} catch (Exception e) {

			}

			CCode = new TableColumn("CCode");
			CCode.setMinWidth(54);

			CDate = new TableColumn("CDate");
			CDate.setMinWidth(84);

			CTotal = new TableColumn("CTotal");
			CTotal.setMinWidth(61);

			CValue = new TableColumn("CValue");
			CValue.setMinWidth(65);

			CDept = new TableColumn("CDept");
			CDept.setMinWidth(60);

			payMethod = new TableColumn("payMethod");
			payMethod.setMinWidth(76);

			CCode.setCellValueFactory(new PropertyValueFactory<cost, Integer>("CCode"));
			CDate.setCellValueFactory(new PropertyValueFactory<cost, String>("CDate"));
			CTotal.setCellValueFactory(new PropertyValueFactory<cost, Double>("CTotal"));
			CValue.setCellValueFactory(new PropertyValueFactory<cost, Double>("CValue"));
			CDept.setCellValueFactory(new PropertyValueFactory<cost, Double>("CDept"));
			payMethod.setCellValueFactory(new PropertyValueFactory<cost, String>("payMethod"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select c.cost_code, c.cost_date ,c.total_cost,c.cost_value,c.dept_value,c.doctor_email,c.traetment_code,c.paymethod from patient p , cost c , pay pa  where p.pNum = "
							+ key + " and pa.patientNum = " + key + " and pa.cost_code = c.cost_code;");

			costdata = new ArrayList<cost>();

			while (rs.next()) {
				costdata.add(new cost(Integer.parseInt(rs.getString(1)), rs.getString(2),
						Double.parseDouble(rs.getString(3)), Double.parseDouble(rs.getString(4)),
						Double.parseDouble(rs.getString(5)), rs.getString(6), Integer.parseInt(rs.getString(7)),
						rs.getString(8)));

			}

			costdataList = FXCollections.observableArrayList(costdata);
			costTable.setItems(costdataList);
			costTable.getColumns().addAll(CCode, CDate, CTotal, CValue, CDept, payMethod);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(c.cost_code) FROM cost c;");

			/*
			 * ResultSet rs3 = stmt.
			 * executeQuery("SELECT MAX(c.cost_code) FROM patient p,cost c , pay pa where p.pNum ="
			 * + key + " and pa.patientNum = " + key + " and pa.cost_code = c.cost_code;");
			 */

			if (rs.next()) {
				maxCost = Integer.parseInt(rs.getString(1));
			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * 
			 * Update cost Table
			 * 
			 * 
			 */

			costTable.setEditable(true);

			CDate.setCellFactory(TextFieldTableCell.<cost>forTableColumn());
			CDate.setOnEditCommit((CellEditEvent<cost, String> t) -> {
				((cost) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCDate(t.getNewValue());
				updateCostDate(t.getRowValue().getCCode(), t.getNewValue());
			});

			CTotal.setCellFactory(TextFieldTableCell.<cost, Double>forTableColumn(new DoubleStringConverter()));
			CTotal.setOnEditCommit((CellEditEvent<cost, Double> t) -> {
				((cost) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCTotal(t.getNewValue());
				updateTotalcost(t.getRowValue().getCCode(), t.getNewValue());
			});

			CValue.setCellFactory(TextFieldTableCell.<cost, Double>forTableColumn(new DoubleStringConverter()));
			CValue.setOnEditCommit((CellEditEvent<cost, Double> t) -> {
				((cost) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCValue(t.getNewValue());
				updateCostValue(t.getRowValue().getCCode(), t.getNewValue());
			});

			CDept.setCellFactory(TextFieldTableCell.<cost, Double>forTableColumn(new DoubleStringConverter()));
			CDept.setOnEditCommit((CellEditEvent<cost, Double> t) -> {
				((cost) t.getTableView().getItems().get(t.getTablePosition().getRow())).setCDept(t.getNewValue());
				updateDept(t.getRowValue().getCCode(), t.getNewValue());
			});

			payMethod.setCellFactory(TextFieldTableCell.<cost>forTableColumn());
			payMethod.setOnEditCommit((CellEditEvent<cost, String> t) -> {
				((cost) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPayMethod(t.getNewValue());
				updatePaymethod(t.getRowValue().getCCode(), t.getNewValue());
			});

			/*
			 * 
			 * Drug Table
			 * 
			 */

			try {
				drugTable.getColumns().clear();
			} catch (Exception e) {

			}

			DCode = new TableColumn("DCode");
			DCode.setMinWidth(85);

			DName = new TableColumn("DName");
			DName.setMinWidth(75);

			DDStart = new TableColumn("DDStart");
			DDStart.setMinWidth(75);

			DDEnd = new TableColumn("DDEnd");
			DDEnd.setMinWidth(80);

			DDesc = new TableColumn("DDesc");
			DDesc.setMinWidth(85);

			DCode.setCellValueFactory(new PropertyValueFactory<drug, Integer>("DCode"));
			DName.setCellValueFactory(new PropertyValueFactory<drug, String>("DName"));
			DDStart.setCellValueFactory(new PropertyValueFactory<drug, String>("DDStart"));
			DDEnd.setCellValueFactory(new PropertyValueFactory<drug, String>("DDEnd"));
			DDesc.setCellValueFactory(new PropertyValueFactory<drug, String>("DDesc"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select d.drugcode , d.drugname,d.drug_Sdate, d.drug_Edate,d.drug_description  from patient p , presecribed pr , drug d  where p.pNum = "
							+ key + " and pr.patientNum = " + key + " and pr.drugcode = d.drugcode;");

			drugdata = new ArrayList<drug>();

			while (rs.next()) {
				drugdata.add(new drug(Integer.parseInt(rs.getString(1)), rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5)));
			}

			drugdataList = FXCollections.observableArrayList(drugdata);
			drugTable.setItems(drugdataList);
			drugTable.getColumns().addAll(DCode, DName, DDStart, DDEnd, DDesc);

			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MAX(d.drugcode) FROM drug d;");

			if (rs.next()) {
				maxDrug = Integer.parseInt(rs.getString(1));
			}

			con.close();
			stmt.close();
			rs.close();

			/*
			 * 
			 * Update Drug Table
			 * 
			 */
			drugTable.setEditable(true);

			DName.setCellFactory(TextFieldTableCell.<drug>forTableColumn());
			DName.setOnEditCommit((CellEditEvent<drug, String> t) -> {
				((drug) t.getTableView().getItems().get(t.getTablePosition().getRow())).setDName(t.getNewValue());
				updateDName(t.getRowValue().getDCode(), t.getNewValue());
			});

			DDStart.setCellFactory(TextFieldTableCell.<drug>forTableColumn());
			DDStart.setOnEditCommit((CellEditEvent<drug, String> t) -> {
				((drug) t.getTableView().getItems().get(t.getTablePosition().getRow())).setDDStart(t.getNewValue());
				updateDStartD(t.getRowValue().getDCode(), t.getNewValue());
			});

			DDEnd.setCellFactory(TextFieldTableCell.<drug>forTableColumn());
			DDEnd.setOnEditCommit((CellEditEvent<drug, String> t) -> {
				((drug) t.getTableView().getItems().get(t.getTablePosition().getRow())).setDDEnd(t.getNewValue());
				updateDEndD(t.getRowValue().getDCode(), t.getNewValue());
			});

			DDesc.setCellFactory(TextFieldTableCell.<drug>forTableColumn());
			DDesc.setOnEditCommit((CellEditEvent<drug, String> t) -> {
				((drug) t.getTableView().getItems().get(t.getTablePosition().getRow())).setDDesc(t.getNewValue());
				updateDDesc(t.getRowValue().getDCode(), t.getNewValue());
			});

		}

		if (flag == 4 ) {

			try {
				MonAppoPaTable.getColumns().clear();
			} catch (Exception e) {

			}

			ANum = new TableColumn("ANum");
			ANum.setMinWidth(90);

			APatientNum = new TableColumn("APatientNum");
			APatientNum.setMinWidth(110);

			ADate = new TableColumn("ADate");
			ADate.setMinWidth(140);

			AHour = new TableColumn("AHour");
			AHour.setMinWidth(100);

			ADesc = new TableColumn("ADesc");
			ADesc.setMinWidth(170);

			ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
			APatientNum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("APatientNum"));
			ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
			AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
			ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			for (int i = 1; i <= 30; i++) {

				stmt = con.createStatement();
				rs = stmt.executeQuery(
						"select distinct a.appointment_number, a.appointment_patient_number,a.appointment_date,a.appointment_hour,a.appointment_description "
								+ "from patient p , appointment a , reserve r where  a.appointment_date ='2000-1-"+i+"';");

				appodata = new ArrayList<appointment>();

				while (rs.next()) {
					appodata.add(new appointment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
							rs.getString(3), rs.getString(4), rs.getString(5)));
				}

				appodataList = FXCollections.observableArrayList(appodata);
				MonAppoPaTable.setItems(appodataList);

			}

			MonAppoPaTable.getColumns().addAll(ANum, APatientNum, ADate, AHour, ADesc);
			con.close();
			stmt.close();
			rs.close();

		}

	}

	public void LogInBM(ActionEvent event) throws IOException {
		key = 0;
		flag = 0;
		((Node) (event.getSource())).getScene().getWindow().hide();

		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));

		Scene scene = new Scene(root, 600, 601);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.setMinHeight(601);
		primaryStage.setMinWidth(600);
		primaryStage.setTitle("Clinic Care�");
		primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
		primaryStage.show();
	}

	public void PatietsBM(ActionEvent event) throws IOException {

		flag = 1;
		((Node) (event.getSource())).getScene().getWindow().hide();

		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("patientPage.fxml"));

		Scene scene = new Scene(root, 679, 630);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.setMinHeight(630);
		primaryStage.setMinWidth(679);
		primaryStage.setTitle("Clinic Care�");
		primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
		primaryStage.show();
	}

	public void AppointmentBM(ActionEvent event) throws IOException {
		flag = 2;
		((Node) (event.getSource())).getScene().getWindow().hide();

		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("App.fxml"));

		Scene scene = new Scene(root, 616, 703);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.setMinHeight(703);
		primaryStage.setMinWidth(616);
		primaryStage.setTitle("Clinic Care�");
		primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
		primaryStage.show();
	}

	public void InfoBM(ActionEvent event) throws IOException {

		ObservableList<patient> selectedRows = mainTable.getSelectionModel().getSelectedItems();

		ArrayList<patient> rows = new ArrayList<>(selectedRows);

		rows.forEach(row -> {
			mainTable.getItems();
			key = row.getPnum();
		});

		if (key != 0) {
			flag = 3;
			((Node) (event.getSource())).getScene().getWindow().hide();

			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("P_info.fxml"));

			Scene scene = new Scene(root, 1307, 701);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(701);
			primaryStage.setMinWidth(1307);
			primaryStage.setTitle("Clinic Care�");
			primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
			primaryStage.show();
		}
	}

	public void ReportMonth(ActionEvent event) throws IOException {

		flag = 4;
		((Node) (event.getSource())).getScene().getWindow().hide();

		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("Newpatient.fxml"));

		Scene scene = new Scene(root, 985, 531);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.setMinHeight(531);
		primaryStage.setMinWidth(985);
		primaryStage.setTitle("Clinic Care�");
		primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
		primaryStage.show();
	}

	public void InfoBMApp(ActionEvent event) throws IOException {

		ObservableList<appointment> selectedRows = appTable.getSelectionModel().getSelectedItems();

		ArrayList<appointment> rows = new ArrayList<>(selectedRows);

		rows.forEach(row -> {
			appTable.getItems();
			key = row.getAPatientNum();
		});

		if (key != 0) {
			flag = 3;
			((Node) (event.getSource())).getScene().getWindow().hide();

			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("P_info.fxml"));

			Scene scene = new Scene(root, 1307, 701);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setMinHeight(701);
			primaryStage.setMinWidth(1307);
			primaryStage.setTitle("Clinic Care�");
			primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("icon.jpg")));
			primaryStage.show();
		}
	}

	public void InsertPatient(ActionEvent event) throws IOException {

		pnum.setCellValueFactory(new PropertyValueFactory<patient, Integer>("pnum"));
		pname.setCellValueFactory(new PropertyValueFactory<patient, String>("pname"));
		p_id.setCellValueFactory(new PropertyValueFactory<patient, Integer>("p_id"));
		address.setCellValueFactory(new PropertyValueFactory<patient, String>("address"));
		dateOfBirth.setCellValueFactory(new PropertyValueFactory<patient, String>("dateOfBirth"));
		sex.setCellValueFactory(new PropertyValueFactory<patient, String>("sex"));
		phoneNum.setCellValueFactory(new PropertyValueFactory<patient, String>("phoneNum"));
		Pstatus.setCellValueFactory(new PropertyValueFactory<patient, String>("Pstatus"));
		patient pa = new patient(maxpatient + 1, "Name", 0, "Address", "2000-1-1", "Sex", "Phone no.", "status");
		mainTable.getItems().add(pa);
		insertPatData(pa);
	}

	private void insertPatData(patient p) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("INSERT INTO patient VALUES(" + p.getPnum() + ",'" + p.getPname() + "'," + p.getP_id()
					+ ",'" + p.getAddress() + "','" + p.getDateOfBirth() + "','" + p.getSex() + "','" + p.getPhoneNum()
					+ "','" + p.getPstatus() + "');");
			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertAppointment(ActionEvent event) throws IOException {

		ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
		APatientNum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("APatientNum"));
		ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
		AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
		ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
		appointment a = new appointment(maxappo + 1, 0, "2000-1-1", "Hour", "Descreption");
		appTable.getItems().add(a);
		insertAppoData(a);

	}

	private void insertAppoData(appointment p) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into appointment values(" + p.getANum() + "," + p.getAPatientNum() + ",'"
					+ p.getADate() + "','" + p.getAHour() + "','" + p.getADesc() + "');");

			ExecuteStatement2("insert into reserve values (" + p.getAPatientNum() + "," + p.getANum()
					+ ",\"ayadental@gmail.com\");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void deleteAppo(ActionEvent event) throws IOException {

		ObservableList<appointment> selectedRows = appTable.getSelectionModel().getSelectedItems();

		ArrayList<appointment> rows = new ArrayList<>(selectedRows);

		rows.forEach(row -> {
			appTable.getItems().remove(row);
			deleteAppoRow(row);
			appTable.refresh();
		});

	}

	private void deleteAppoRow(appointment p) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("delete from reserve r where r.appointment_number =" + p.getANum() + ";");

			ExecuteStatement2("delete from  appointment where appointment_number=" + p.getANum() + ";");
			initialize();
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertDiag(ActionEvent event) throws IOException {

		DiaCode.setCellValueFactory(new PropertyValueFactory<diagnosis, Integer>("DiaCode"));
		DiaName.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("DiaName"));
		TreatNeed.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("TreatNeed"));
		DiaDesc.setCellValueFactory(new PropertyValueFactory<diagnosis, String>("DiaDesc"));

		diagnosis d = new diagnosis(maxdaig + 1, "Problem Name", "Treatment", "Description");
		diagTable.getItems().add(d);
		insertDiagData(d);

	}

	private void insertDiagData(diagnosis d) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into diagnosis values(" + d.getDiaCode() + ",'" + d.getDiaName() + "','"
					+ d.getTreatNeed() + "','" + d.getDiaDesc() + "');");

			ExecuteStatement2("insert into visit values (" + Integer.parseInt(patNumT.getText()) + "," + d.getDiaCode()
					+ ",\"ayadental@gmail.com\");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void insertNULLDiagData() {

		try {
			diagnosis d = new diagnosis(maxdaig + 1, "Problem Name", "Treatment", "Description");
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into diagnosis values(" + d.getDiaCode() + ",'" + d.getDiaName() + "','"
					+ d.getTreatNeed() + "','" + d.getDiaDesc() + "');");

			ExecuteStatement2("insert into visit values (" + Integer.parseInt(patNumT.getText()) + "," + d.getDiaCode()
					+ ",\"ayadental@gmail.com\");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertTreat(ActionEvent event) throws IOException {

		TCode.setCellValueFactory(new PropertyValueFactory<treatment, Integer>("TCode"));
		TID.setCellValueFactory(new PropertyValueFactory<treatment, Integer>("TID"));
		TName.setCellValueFactory(new PropertyValueFactory<treatment, String>("TName"));
		TArea.setCellValueFactory(new PropertyValueFactory<treatment, String>("TArea"));
		TDesc.setCellValueFactory(new PropertyValueFactory<treatment, String>("TDesc"));

		treatment t = new treatment(maxtreat + 1, 0, "Name", "Area", "Description", "", 0);

		treatTable.getItems().add(t);
		insertTreatData(t);

	}

	private void insertTreatData(treatment t) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into treatment values(" + t.getTCode() + "," + t.getTID() + ",'" + t.getTName()
					+ "','" + t.getTArea() + "','" + t.getTDesc() + "',\"ayadental@gmail.com\"," + maxdaigTrear + ");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void insertNULLTreatData() {

		try {
			treatment t = new treatment(maxtreat + 1, 0, "Name", "Area", "Description", "", 0);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into treatment values(" + t.getTCode() + "," + t.getTID() + ",'" + t.getTName()
					+ "','" + t.getTArea() + "','" + t.getTDesc() + "',\"ayadental@gmail.com\"," + maxdaigTrear + ");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertPatAppo(ActionEvent event) throws IOException {

		ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
		ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
		AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
		ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
		appointment a = new appointment(maxPatappo + 1, Integer.parseInt(patNumT.getText()), "2000-1-1", "Hour",
				"Description");

		appoPaTable.getItems().add(a);
		insertPatAppoData(a);
	}

	private void insertPatAppoData(appointment p) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2(
					"insert into appointment values(" + p.getANum() + "," + Integer.parseInt(patNumT.getText()) + ",'"
							+ p.getADate() + "','" + p.getAHour() + "','" + p.getADesc() + "');");

			ExecuteStatement2("insert into reserve values (" + Integer.parseInt(patNumT.getText()) + "," + p.getANum()
					+ ",\"ayadental@gmail.com\");");
			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void insertNULLPatAppoData() {

		try {
			appointment p = new appointment(maxPatappo + 1, Integer.parseInt(patNumT.getText()), "2000-1-1", "Hour",
					"Description");
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2(
					"insert into appointment values(" + p.getANum() + "," + Integer.parseInt(patNumT.getText()) + ",'"
							+ p.getADate() + "','" + p.getAHour() + "','" + p.getADesc() + "');");

			ExecuteStatement2("insert into reserve values (" + Integer.parseInt(patNumT.getText()) + "," + p.getANum()
					+ ",\"ayadental@gmail.com\");");
			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertCost(ActionEvent event) throws IOException {

		CCode.setCellValueFactory(new PropertyValueFactory<cost, Integer>("CCode"));
		CDate.setCellValueFactory(new PropertyValueFactory<cost, String>("CDate"));
		CTotal.setCellValueFactory(new PropertyValueFactory<cost, Double>("CTotal"));
		CValue.setCellValueFactory(new PropertyValueFactory<cost, Double>("CValue"));
		CDept.setCellValueFactory(new PropertyValueFactory<cost, Double>("CDept"));
		payMethod.setCellValueFactory(new PropertyValueFactory<cost, String>("payMethod"));

		cost c = new cost(maxCost + 1, "2000-1-1", 0, 0, 0, "ayadental@gmail.com", 0, "payMethod");

		costTable.getItems().add(c);
		insertCostData(c);
	}

	private void insertCostData(cost c) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into cost values (" + c.getCCode() + ",'" + c.getCDate() + "'," + c.getCTotal()
					+ "," + c.getCValue() + "," + c.getCDept() + ",\"ayadental@gmail.com\"," + maxTreatCost + ",'"
					+ c.getPayMethod() + "');");

			ExecuteStatement2("insert into pay values (" + Integer.parseInt(patNumT.getText()) + "," + c.getCCode()
					+ ",'" + c.getPayMethod() + "');");
			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void insertNULLCostData() {

		try {
			cost c = new cost(maxCost + 1, "2000-1-1", 0, 0, 0, "ayadental@gmail.com", 0, "payMethod");
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into cost values (" + c.getCCode() + ",'" + c.getCDate() + "'," + c.getCTotal()
					+ "," + c.getCValue() + "," + c.getCDept() + ",\"ayadental@gmail.com\"," + maxTreatCost + ",'"
					+ c.getPayMethod() + "');");

			ExecuteStatement2("insert into pay values (" + Integer.parseInt(patNumT.getText()) + "," + c.getCCode()
					+ ",'" + c.getPayMethod() + "');");
			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void InsertDrug(ActionEvent event) throws IOException {

		DCode.setCellValueFactory(new PropertyValueFactory<drug, Integer>("DCode"));
		DName.setCellValueFactory(new PropertyValueFactory<drug, String>("DName"));
		DDStart.setCellValueFactory(new PropertyValueFactory<drug, String>("DDStart"));
		DDEnd.setCellValueFactory(new PropertyValueFactory<drug, String>("DDEnd"));
		DDesc.setCellValueFactory(new PropertyValueFactory<drug, String>("DDesc"));

		drug d = new drug(maxDrug + 1, "Name", "2000-1-1", "2000-2-1", "Description");

		drugTable.getItems().add(d);
		insertDrugData(d);
	}

	private void insertDrugData(drug d) {

		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			ExecuteStatement2("insert into drug values (" + d.getDCode() + ",'" + d.getDName() + "','" + d.getDDStart()
					+ "','" + d.getDDEnd() + "','" + d.getDDesc() + "');");

			ExecuteStatement2("insert into presecribed values (" + Integer.parseInt(patNumT.getText()) + ","
					+ d.getDCode() + ",\"ayadental@gmail.com\");");

			initialize();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void searchAppo(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

		if ((searchA.getText()).compareTo("") != 0) {
			ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
			APatientNum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("APatientNum"));
			ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
			AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
			ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select distinct a.appointment_number, a.appointment_patient_number,a.appointment_date,a.appointment_hour,a.appointment_description  from patient p , appointment a , reserve r where  a.appointment_date ='"
							+ searchA.getText() + "';");

			appodata = new ArrayList<appointment>();

			while (rs.next()) {
				appodata.add(new appointment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
						rs.getString(3), rs.getString(4), rs.getString(5)));
			}

			appodataList = FXCollections.observableArrayList(appodata);
			appTable.setItems(appodataList);
		} else
			initialize();

	}

	public void searchPatient(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

		if ((searchP.getText()).compareTo("") != 0) {

			pnum.setCellValueFactory(new PropertyValueFactory<patient, Integer>("pnum"));
			pname.setCellValueFactory(new PropertyValueFactory<patient, String>("pname"));
			p_id.setCellValueFactory(new PropertyValueFactory<patient, Integer>("p_id"));
			address.setCellValueFactory(new PropertyValueFactory<patient, String>("address"));
			dateOfBirth.setCellValueFactory(new PropertyValueFactory<patient, String>("dateOfBirth"));
			sex.setCellValueFactory(new PropertyValueFactory<patient, String>("sex"));
			phoneNum.setCellValueFactory(new PropertyValueFactory<patient, String>("phoneNum"));
			Pstatus.setCellValueFactory(new PropertyValueFactory<patient, String>("Pstatus"));

			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);

			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from patient p where p.pNum = " + searchP.getText() + ";");
			pdata = new ArrayList<patient>();
			while (rs.next()) {
				pdata.add(new patient(Integer.parseInt(rs.getString(1)), rs.getString(2),
						Integer.parseInt(rs.getString(3)), rs.getString(4), rs.getString(5), rs.getString(6),
						rs.getString(7), rs.getString(8)));
			}

			PdataList = FXCollections.observableArrayList(pdata);
			mainTable.setItems(PdataList);
		} else
			initialize();

	}

	public void ShowBM(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {
		mon++;
		System.out.println("111");
		if ((showMon.getText()).compareTo("") != 0) {
			
			System.out.println("222");
			ANum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("ANum"));
			APatientNum.setCellValueFactory(new PropertyValueFactory<appointment, Integer>("APatientNum"));
			ADate.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADate"));
			AHour.setCellValueFactory(new PropertyValueFactory<appointment, String>("AHour"));
			ADesc.setCellValueFactory(new PropertyValueFactory<appointment, String>("ADesc"));
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			System.out.println("333");
			if (con != null) {

			} else {
				System.out.println("Not connected !");
			}

			for (int i = 1; i <= 30; i++) {

				stmt = con.createStatement();
				rs = stmt.executeQuery(
						"select distinct a.appointment_number, a.appointment_patient_number,a.appointment_date,a.appointment_hour,a.appointment_description "
								+ "from patient p , appointment a , reserve r where  a.appointment_date ='"
								+ showMon.getText() + "-" + i + "';");
				System.out.println(showMon.getText() + "-" + i);
				appodata = new ArrayList<appointment>();
				
				while (rs.next()) {
					appodata.add(new appointment(Integer.parseInt(rs.getString(1)), Integer.parseInt(rs.getString(2)),
							rs.getString(3), rs.getString(4), rs.getString(5)));
				}

				appodataList = FXCollections.observableArrayList(appodata);
				MonAppoPaTable.setItems(appodataList);

			}
		} 

	}

	public void ExecuteStatement2(String SQL) throws SQLException {

		try {
			stmt = con.createStatement();
			stmt.executeUpdate(SQL);
			stmt.close();

		} catch (SQLException s) {
			s.printStackTrace();
			System.out.println("SQL statement is not executed!");

		}

	}

}
