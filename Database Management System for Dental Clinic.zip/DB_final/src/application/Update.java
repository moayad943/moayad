package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class Update {

	private Connection con;
	@FXML
	private TextArea note;

	/*
	 * Update Patient
	 * 
	 */

	protected void updateName(int pnum, String newname) {
		try {
			note.setText("update patient name, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update  patient set pname = '" + newname + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatepatientID(int pnum, int newname) {
		try {
			note.setText("update patient ID, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update patient set pIdentity = '" + newname + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateAdderss(int pnum, String newAdderss) {
		try {
			note.setText("update patient Adderss, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update  patient set pAddress = '" + newAdderss + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatepatientDOB(int pnum, String newname) {
		try {
			note.setText("update patient D.O.B, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update patient set dateofbirth = '" + newname + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatepatientSex(int pnum, String newname) {
		try {
			note.setText("update patient Sex, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update patient set sex = '" + newname + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatePhoneNum(int pnum, String newPhoneNum) {
		try {
			note.setText("update patient phone number, where pnum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update  patient set patient_phone = '" + newPhoneNum + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatePstatus(int pnum, String newPstatus) {
		try {
			note.setText("update patient status, where pNum = " + pnum);
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update  patient set pStatus = '" + newPstatus + "' where pnum = " + pnum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * Update Appointment
	 */

	protected void updateAPat(int ANum, int newdate) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update Appointment  set appointment_patient_number = '" + newdate
					+ "' where appointment_number = " + ANum + ";");
			
			ExecuteStatement("insert into reserve values (" + newdate + "," + ANum + ",\"ayadental@gmail.com\");");

			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateADate(int ANum, String newdate) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update Appointment  set appointment_date = '" + newdate + "' where appointment_number = "
					+ ANum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateAHour(int ANum, String newHour) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update appointment set appointment_hour = '" + newHour + "' where appointment_number = "
					+ ANum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateADesc(int ANum, String newdesc) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update Appointment set appointment_description = '" + newdesc
					+ "' where appointment_number = " + ANum + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * Update diagnoses
	 */

	protected void updateDiaName(int DiaCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement(
					"update diagnosis set problem_name = '" + newname + "' where diagnosis_code = " + DiaCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatetreatneed(int DiaCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement(
					"update diagnosis set tratment_need = '" + newname + "' where diagnosis_code = " + DiaCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateDdesc(int DiaCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update diagnosis set diagnosis_description = '" + newname + "' where diagnosis_code = "
					+ DiaCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * Update treatment
	 */

	protected void updateTID(int TCode, int newdata) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement(
					"update treatment set treatment_id = '" + newdata + "' where traetment_code = " + TCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateTName(int TCode, String newdata) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement(
					"update treatment set traetment_name = '" + newdata + "' where traetment_code = " + TCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateTArea(int TCode, String newdata) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement(
					"update treatment set traetment_area = '" + newdata + "' where traetment_code = " + TCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateTDesc(int TCode, String newdata) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update treatment set treatment_description = '" + newdata + "' where traetment_code = "
					+ TCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * Update cost
	 */

	protected void updateCostDate(int CCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update cost set cost_date = '" + newname + "' where cost_code = " + CCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	protected void updateTotalcost(int CCode, Double newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update cost set total_cost = '" + newname + "' where cost_code = " + CCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateCostValue(int CCode, Double newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update cost set cost_value = '" + newname + "' where cost_code = " + CCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateDept(int CCode, Double newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update cost set dept_value = '" + newname + "' where cost_code = " + CCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updatePaymethod(int CCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update cost set paymethod = '" + newname + "' where cost_code = " + CCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	/*
	 * 
	 * Update drug
	 */

	protected void updateDName(int DCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update drug set drugname = '" + newname + "' where drugcode = " + DCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateDStartD(int DCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update drug set drug_Sdate = '" + newname + "' where drugcode = " + DCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateDEndD(int DCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update drug set drug_Edate = '" + newname + "' where drugcode = " + DCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	protected void updateDDesc(int DCode, String newname) {
		try {
			con = null;
			Class.forName(DBconnection.Class);
			con = DriverManager.getConnection(DBconnection.URL, DBconnection.DBUserDbUsername, DBconnection.DbPassword);
			ExecuteStatement("update drug set drug_description = '" + newname + "' where drugcode = " + DCode + ";");
			con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * Execute Statement
	 */

	protected void ExecuteStatement(String SQL) throws SQLException {

		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(SQL);
			stmt.close();

		} catch (SQLException s) {
			s.printStackTrace();
			System.out.println("SQL statement is not executed!");

		}

	}

}
