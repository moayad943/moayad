package application;

public class DBconnection {
	static final String Class = "com.mysql.jdbc.Driver";
	static final String URL = "jdbc:mysql://localhost:3306/DentalClinic?autoReconnect=true&useSSL=false";
	static final String DBUserDbUsername = "root";
	static final String DbPassword = "root";
}
